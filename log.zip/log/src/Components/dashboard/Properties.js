import React from 'react'
import "./Properties.scss"
import img from "./../../assets/pexels-pixabay-220453.jpeg"
import img1 from "./../../assets/pexels-koolshooters-6976943.jpg"
import img2 from "./../../assets/pexels-suliman-sallehi-1704488.jpg"
import {BsSearch} from "react-icons/bs"
const Properties = () => {
  return (
    <div className='properties'>
      <div className='prop-header' >
         <div className='heading'>Properties</div>
         <div className='search'><BsSearch/><input placeholder='search' /></div>
      </div>
      <hr/>
      <div className='prop-content' >
       <div className='prop-prop'>
          <div className='receiver' >Receiver</div>
          <div className='type'>Type</div>
          <div className='status'> Status</div>
          <div className='date'>date</div>
          <div className='amount'>Amount</div>
       </div>
      </div>
      <div className='prop-content' >
       <div className='prop-prop-con'>
          <div className='receiver1'>
          <input type='checkbox' style={{marginRight:"10px"}}/><img className='prop-img' src={img}/>Emma ryan jr.</div>
          <div className='type1'>Type</div>
          <div className='status1'> <div className='pen'>pending</div></div>
          <div className='date1'>date</div>
          <div className='amount1'>Amount <div className='details-btn'>Details</div></div>
       </div>
      </div>
      <div className='prop-content' >
       <div className='prop-prop-con'>
          <div className='receiver1'>
          <input type='checkbox' style={{marginRight:"10px"}}/><img className='prop-img' src={img1}/>Emma ryan jr.</div>
          <div className='type1'>Type</div>
          <div className='status1'> <div className='pen' style={{backgroundColor:"#e6f6f5" ,color:"#77a3a4"}}>Done</div></div>
          <div className='date1'>date</div>
          <div className='amount1'>Amount <div className='details-btn'>Details</div></div>
       </div>
      </div>
      <div className='prop-content' >
       <div className='prop-prop-con'>
          <div className='receiver1'>
          <input type='checkbox' style={{marginRight:"10px"}}/><img className='prop-img' src={img2}/>Emma ryan jr.</div>
          <div className='type1'>Type</div>
          <div className='status1'> <div className='pen'>pending</div></div>
          <div className='date1'>date</div>
          <div className='amount1'>Amount <div className='details-btn'>Details</div></div>
       </div>
      </div>
    </div>
  )
}

export default Properties
