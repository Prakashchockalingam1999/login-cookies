import { Navigate, Outlet, Route, Routes } from "react-router-dom";
import cookie from "react-cookies";
import Dashboard from "./dashboard/Dashboard";

const PrivateRoutes = () => {
  function cookieready() {
    const cookieValue = cookie.load("token");
    console.log(cookieValue);
    return cookieValue;
  }

  return (
    <Routes>
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/" element={<Navigate to="/dashboard" replace />} />
      <Route path="/login" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
};
export default PrivateRoutes;
